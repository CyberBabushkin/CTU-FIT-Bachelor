package bi.zum.lab3;

import cz.cvut.fit.zum.api.ga.AbstractEvolution;
import cz.cvut.fit.zum.api.ga.AbstractIndividual;
import cz.cvut.fit.zum.api.ga.AbstractPopulation;
import cz.cvut.fit.zum.data.StateSpace;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Comparator;

/**
 * @author Andrey Babushkin
 */
public class Population extends AbstractPopulation {

    AbstractEvolution myEv;
    
    public Population(AbstractEvolution evolution, int size) {
        individuals = new Individual[size];
        myEv = evolution;
        for (int i = 0; i < individuals.length; i++) {
            individuals[i] = new Individual(evolution, true);
            individuals[i].computeFitness();
        }
    }
    
    public void differentialCrossover( double mul, double crossProb )
    {
        Random r = new Random();
        for ( int i = 0; i < individuals.length; i++ )
        {
            List<AbstractIndividual> mutators = selectIndividuals(2);
            AbstractIndividual best = getBestIndividual();
            while ( mutators.contains(individuals[i]) 
                    || mutators.contains(best) )
                mutators = selectIndividuals(2);
            Individual mutant = new Individual( myEv, false );
            AbstractIndividual def = individuals[i].deepCopy();
            
            for ( int j = 0; j < StateSpace.nodesCount(); j++ )
            {
                double val;
                val = ((Individual)best).getNodeValue(j) +
                        mul * ( ((Individual)mutators.get(0)).getNodeValue(j) -
                            ((Individual)mutators.get(1)).getNodeValue(j) );
                while ( val > 0.5 )
                    val /= 2.;
                while ( val < -0.5 )
                    val /= 2.;
                mutant.setNodeValue(j, val);
            }
            if ( r.nextDouble() < crossProb )
                def.crossover( mutant );
            if ( def.getFitness() > individuals[i].getFitness() )
                setIndividualAt( i, def );
        }
    }
    
    public void hill()
    {
        for ( Individual ind : (Individual [] )individuals )
            ind.hillClimbing();
    }
    
    boolean checkConvergence()
    {
        double cosDist = 0.;
        for ( int i = 0; i < size() - 1; i++ )
        {
            Individual in1 = (Individual)getIndividual(i);
            Individual in2 = (Individual)getIndividual(i+1);
            cosDist += Individual.cosDist( in1, in2 );
        }
        cosDist /= size() - 1;
        if ( cosDist < 0.1 )
            return true;
        else
            return false;
    }
    
    public class cmp implements Comparator<AbstractIndividual> {

        @Override
        public int compare(AbstractIndividual o1, AbstractIndividual o2) {
            if ( o1.getFitness() > o2.getFitness() )
                return 1;
            else if ( o1.getFitness() < o2.getFitness() )
                return -1;
            else 
                return 0;
        }
    }
    
    int rouletteSelect( double[] weight ) {
        Random r = new Random();
	double weight_sum = 0;
	for( int i = 0; i < weight.length; i++ ) {
		weight_sum += weight[i];
	}
	double value = r.nextDouble() * weight_sum;
	for ( int i = 0; i < weight.length; i++ ) 
        {		
		value -= weight[i];		
		if ( value <= 0 ) return i;
	}
	return weight.length - 1;
    }
    
    /**
     * Method to select individuals from population
     *
     * @param count The number of individuals to be selected
     * @return List of selected individuals
     */
    public List<AbstractIndividual> selectIndividuals(int count) {
        
        ArrayList<AbstractIndividual> selected = new ArrayList<AbstractIndividual>();
        ArrayList<AbstractIndividual> tourSelect = new ArrayList<AbstractIndividual>();
        Random r = new Random();
        int tournPop = size() / count;
        int part = 1;
        
        // ================================================================== //
        // ====================Clean tournament selection==================== //
        // ================================================================== //
        
        while (selected.size() != count)
        {
            while ( tourSelect.size() != tournPop )
            {
                AbstractIndividual randIndividual = individuals[ r.nextInt(individuals.length / count) * part ];
                tourSelect.add( randIndividual );
            }
            /*
            double wheelFit = 0.;
            tourSelect.sort( new cmp() );
            
            double probs[] = new double[ tournPop ];
            
            for ( int i = 0; i < tournPop; i++ )
            {
                AbstractIndividual ind = tourSelect.get(i);
                wheelFit += ind.getFitness();
            }
            
            for ( int i = 0; i < tournPop; i++ )
            {
                AbstractIndividual ind = tourSelect.get(i);
                probs[i] = ind.getFitness() / wheelFit;
                if ( i != 0 ) probs[i] += probs[i-1];
            }
            
            int index = rouletteSelect( probs );
            
            AbstractIndividual ind = tourSelect.get(index);*/
            
            int index = 0;
            AbstractIndividual ind = tourSelect.get(0);
            
            for ( AbstractIndividual ai : tourSelect )
            {
                if ( ai.getFitness() > ind.getFitness() )
                    ind = ai;
            }
            
            if ( !selected.contains(ind) )
            {
                selected.add(ind);
                part++;
            }
            tourSelect.clear();
        }
        
        return selected;
    }
}
