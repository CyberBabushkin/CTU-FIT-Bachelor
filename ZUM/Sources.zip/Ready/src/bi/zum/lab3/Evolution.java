package bi.zum.lab3;

import cz.cvut.fit.zum.util.Pair;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.io.IOException;

import cz.cvut.fit.zum.api.ga.AbstractEvolution;
import cz.cvut.fit.zum.api.ga.AbstractIndividual;
import cz.cvut.fit.zum.data.StateSpace;
import java.util.Random;
import org.openide.util.lookup.ServiceProvider;
import cz.cvut.fit.zum.utils.ScoreCommit.*;
import java.io.PrintWriter;
import java.io.File;
import java.io.FileNotFoundException;
import org.openide.util.Exceptions;

/**
 * @author Your name
 */
@ServiceProvider(service = AbstractEvolution.class)
public class Evolution extends AbstractEvolution<Individual> implements Runnable {

    /**
     * start and final average fitness
     */
    private Pair<Double, Double> avgFitness;
    /**
     * start and final best fitness in whole population
     */
    private Pair<Double, Double> bestFitness;
    /**
     * start and final time
     */
    private Pair<Long, Long> time;
    /**
     * How often to print status of evolution
     */
    private int debugLimit = 100;
    private Random rand = new Random();
    public final int threadsCount = 2;
    /**
     * The population to be used in the evolution
     */

    public Evolution() {
        isFinished = false;
        avgFitness = new Pair<Double, Double>();
        bestFitness = new Pair<Double, Double>();
        time = new Pair<Long, Long>();        
    }

    @Override
    public String getName() {
        return "My evolution";
    }
    
    public class EvolutionThread extends Thread
    {
        volatile Population population;
        Evolution myEv;
        
        private int lastFitChangeCtr;
        private double lastFitState;
        
        public volatile boolean exchangeNeeded = false;
        private volatile int lastExCtr = 0;
        public volatile EvolutionThread exThread;
        public volatile AbstractIndividual myBest;
        
        public EvolutionThread( Evolution ev, String d )
        {
            population = new Population( ev, populationSize );
            myEv = ev;
            lastFitChangeCtr = 0;
            lastFitState = - 10000000000000.;
            
            this.setName( d );
        }
        
        public void exchange( )
        {
            if ( null != exThread )
            {
                int r = rand.nextInt( population.size() );
                while ( population.getIndividual(r) == population.getBestIndividual() )
                    r = rand.nextInt( population.size() );
                population.setIndividualAt( r, exThread.getRandom() );
            }
        }
        
        public void exchangeBest( )
        {
            if ( null != exThread )
            {
                population.sortByFitness();
                population.setIndividualAt( 0, exThread.getBest() );
            }
        }
        
        public AbstractIndividual getBest()
        {
            return population.getBestIndividual().deepCopy();
        }
        
        public AbstractIndividual getRandom()
        {
            int r = rand.nextInt( population.size() );
            return population.getIndividual(r).deepCopy();
        }
        
        @Override
        public void run() {
            
            double lastWrittenBest = -100000000000000.;
            double time = System.currentTimeMillis();
            
            File file = new File("/Users/mannannlegur/Downloads/SemOut/3_" + getName() + ".txt");
            file.getParentFile().mkdirs();
            PrintWriter writer;
            try {
                writer = new PrintWriter(file);
            } catch (FileNotFoundException ex) {
                Exceptions.printStackTrace(ex);
                return;
            }
            
            Random random = new Random();

            // Run evolution cycle for the number of generations set in GUI
            for (int g = 0; g < generations; g++) {

                // the evolution may be terminate from the outside using GUI button
                if ( isFinished ) {
                    break;
                }
                
                // initialize the next generation's population
                ArrayList<AbstractIndividual> newInds = new ArrayList<AbstractIndividual>();

                // elitism: Preserve the best individual
                // (this is quite exploatory and may lead to premature convergence!)
                newInds.add(population.getBestIndividual().deepCopy());
                
                if ( rand.nextDouble() < 0.001 )
                {
                    System.out.println( "Injectiing in " + getName() );
                    newInds.add( new Individual( myEv, true ) );
                }
                
                if (g > 0) {
                    double bestFit = myBest.getFitness();
                    if (bestFit > lastFitState) {
                        lastFitChangeCtr = 0;
                        lastFitState = bestFit;
                    } else {
                        lastFitChangeCtr++;
                    }

                    if (lastFitChangeCtr == 50 ) {
                        lastFitChangeCtr = 0;
                        if (population.checkConvergence()) {
                            Population newOne = new Population(myEv, (int) (populationSize / 10));
                            for (int i = 0; i < newOne.size(); i++) {
                                newInds.add(newOne.getIndividual(i));
                            }
                            System.out.println("A catastrophe in " + getName() + "!");
                        }
                    }
                }
                
                // keep filling the new population while not enough individuals in there
                while (newInds.size() < populationSize) {
                    
                    // select 2 parents
                    List<AbstractIndividual> parents = population.selectIndividuals(2);

                    Pair<AbstractIndividual, AbstractIndividual> offspring;

                    // with some probability, perform crossover
                    if (random.nextDouble() < crossoverProbability) {
                        offspring = parents.get(0).deepCopy().crossover(
                                parents.get(1).deepCopy());
                    } // otherwise, only copy the parents
                    else {
                        offspring = new Pair<AbstractIndividual, AbstractIndividual>();
                        offspring.a = parents.get(0).deepCopy();
                        offspring.b = parents.get(1).deepCopy();
                    }

                    // mutate first offspring, add it to the new population
                    offspring.a.mutate(mutationProbability);
                    offspring.a.computeFitness();
                    
                    if (newInds.size() < populationSize)
                        newInds.add(offspring.a);

                    // if there is still space left in the new population, add also
                    // the second offspring
                    if (newInds.size() < populationSize) {
                        offspring.b.mutate(mutationProbability);
                        offspring.b.computeFitness();
                        newInds.add(offspring.b);
                    }
                }

                // replace the current population with the new one
                for (int i = 0; i < newInds.size(); i++) {
                    population.setIndividualAt(i, newInds.get(i));
                }

                // print statistic
                System.out.println(this.getName() + " gen: " + g 
                        + "\t bestFit: " + population.getBestIndividual().getFitness() 
                        + "\t avgFit: " + population.getAvgFitness());
                
                myBest = getBest();
                if ( exchangeNeeded ) 
                {
                    if ( lastExCtr == 0 )
                    {
                        exchangeNeeded = false;
                        lastExCtr = 0;
                        exchange();
                        System.out.println( "An exchange in " + getName() + " occured!" );
                    } else 
                        lastExCtr ++;
                }
                
                if ( rand.nextDouble() < 0.001 )
                {
                    System.out.println( "The best in " + getName() + " was replaced." );
                    exchangeBest();
                }
                
                myEv.getBestFromThread(this, this.getBest());
                updateGenerationNumber( g );
                if ( rand.nextDouble() <= 0.001 )
                {
                    System.out.println( "Hill climbing for the whole " + 
                            "population in " + getName() );
                    population.hill();
                } 
                
                if (g > 0 
                        && Math.abs(lastWrittenBest - population.getBestIndividual().getFitness()) > 0.1 ) {
                    lastWrittenBest = population.getBestIndividual().getFitness();
                    writer.print(g);
                    writer.print(" ");
                    writer.print(System.currentTimeMillis() - time);
                    writer.print(" ");
                    writer.print(lastWrittenBest);
                    writer.println();
                }
            }
            
            myEv.getBestFromThread(this, this.getBest());
            writer.close();
            System.out.println( "Thread " + getName() + " has finished." );
        }
    }
    
    volatile boolean [] threadsLives;
    volatile AbstractIndividual [] bests;
    EvolutionThread [] threads;
    
    public void getBestFromThread( EvolutionThread elTh, AbstractIndividual ind )
    {
        for ( int i = 0; i < threadsCount; i++ )
        {
            if ( elTh.getName().equals( "" + i ) )
            {
                bests[i] = ind;
                threadsLives[i] = false; 
                break;
            }
        }
    }
    
    boolean allDead()
    {
        boolean a = true;
        for ( int i = 0; i < threadsCount; i ++  )
        {
            if ( threads[i].isAlive() )
            {
                return false;
            }
        }
        return true;
    }
    
    @Override
    public void run() {
        
        Individual ind = new Individual( this, true );
        updateMap(ind);
        //if ( true ) return; 
        
        threads = new EvolutionThread[ threadsCount ];
        bests = new AbstractIndividual[ threadsCount ];
        
        threadsLives = new boolean[ threadsCount ];
        for ( int j = 0; j < threadsCount; j++ )
        {
            threadsLives[j] = true;
        }
        
        for ( int i = 0; i < threadsCount; i++ )
        {
            threads[i] = new EvolutionThread( this, "" + i );
        }
        
        for ( Thread t : threads )
        {
            t.start();
        }
        
        try{ java.lang.Thread.sleep(10000); }catch(InterruptedException ex){}
        
        while ( !isFinished )
        {
            if ( allDead() ) { System.out.println( "All threads are dead. :(" ); break; }
            
            int index = 0;
            double fit = -10e100;
            
            for ( int i = 0; i < threadsCount; i++ )
            {
                if ( bests[i].getFitness() > fit )
                {
                    fit = bests[i].getFitness();
                    index = i;
                }
            }
            
            updateMap( bests[index] );
            
            int first = rand.nextInt(threadsCount);
            int second = rand.nextInt(threadsCount);
            
            while ( ! allDead() &&
                    ! isFinished && (
                    first == second ||
                    ! threads[first].isAlive() ||
                    ! threads[second].isAlive() ) )  
            {
                first = rand.nextInt(threadsCount);
                second = rand.nextInt(threadsCount);
            }
            threads[first].exThread = threads[second];
            threads[second].exThread = threads[first];
            threads[first].exchangeNeeded = true;
            threads[second].exchangeNeeded = true;
            
            try{ java.lang.Thread.sleep(30000); }catch(InterruptedException ex){}
        }
        
        try
        {
            Thread.sleep(30000);
        } catch ( InterruptedException ex ) {}
        
        double fit = -10e100;
        int index = 0;
        for (int i = 0; i < threadsCount; i++) {
            if (bests[i].getFitness() > fit) {
                fit = bests[i].getFitness();
                index = i;
            }
        }

        AbstractIndividual best = bests[index];
        
        // === END ===
        updateMap(best);
        System.out.println( "bestFitness = " + best.getFitness() );
        System.out.println( "bestIndividual= " + best );
        //System.out.println(pop);

        ScoreCommiter sc = new ScoreCommiter(
            new Token("ef74e43b8d66604a038dcd3a0b7aa0df"),
            "http://zum.fitak.cz/commit/%token%/%apiversion%");
        
        Score s = new Score();
        for ( int i = 0; i < StateSpace.nodesCount(); i++ )
            if ( best.isNodeSelected(i) )
                s.addNode(i);
            
        try {
            System.out.print( "Do you want to post your results?  " );
            if ( (char)System.in.read() == 'y' )
            {
                sc.commitScore(s);
                System.out.println("========== Posted to zum.fitak.cz =============");
            }
        } catch ( IOException ex ) {}
        isFinished = true;
        System.out.println("========== Evolution finished =============");
    }
}
// 1264
// 1502
// 5170 to 5748
