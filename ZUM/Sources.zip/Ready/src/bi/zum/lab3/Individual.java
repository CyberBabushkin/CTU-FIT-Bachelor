package bi.zum.lab3;

import cz.cvut.fit.zum.api.ga.AbstractEvolution;
import cz.cvut.fit.zum.api.ga.AbstractIndividual;
import cz.cvut.fit.zum.data.Edge;
import cz.cvut.fit.zum.data.StateSpace;
import cz.cvut.fit.zum.util.Pair;
import static java.lang.System.in;
import java.util.Random;
import java.util.HashSet;
import java.util.List;
import cz.cvut.fit.zum.api.Node;

/**
 * @author Your Name
 */
public class Individual extends AbstractIndividual {

    private double fitness = Double.NaN;
    private final AbstractEvolution evolution;
    private double[] covering;
    private boolean[] varNodes;
    private int coveredNodes = 0;
    private int maxEdgesCount = 0;
    
    static double cosDist( Individual ind1, Individual ind2 )
    {
        double size1 = 0, size2 = 0, prod = 0.;
        for ( int i = 0; i < ind1.covering.length; i++ )
        {
            size1 += Math.pow(ind1.covering[i], 2);
            size2 += Math.pow(ind2.covering[i], 2);
            prod += ind1.covering[i] * ind2.covering[i];
        }
        size1 = Math.sqrt(size1);
        size2 = Math.sqrt(size2);
        return 1 - prod / size1 / size2;
    }
    
    public void hillClimbing( )
    {
        Random r = new Random();
        
        Individual newInd = new Individual( evolution, false );
        newInd.covering = covering.clone();
        
        int numberOfMutations = r.nextInt( covering.length / 10 );
        
        boolean cont = true;
        while (cont) {
            cont = false;
            int nmr = r.nextInt(covering.length / 50);
            
            for (int space = 0; space < nmr; space++) {
                for (int i = 0; i < numberOfMutations; i++) {
                    int mutationIndex = r.nextInt(newInd.covering.length);
                    if ( varNodes[mutationIndex] )
                        newInd.covering[mutationIndex] += r.nextGaussian() / 8;
                    else 
                        i--;
                }

                newInd.repairDNA();
                
                if ( newInd.getFitness() >= getFitness() )
                {
                    cont = true;
                    covering = newInd.covering.clone();
                    fitness = newInd.fitness;
                    coveredNodes = newInd.coveredNodes;
                    maxEdgesCount = newInd.maxEdgesCount;
                    break;
                } else {
                    newInd.covering = covering.clone();
                    newInd.fitness = fitness;
                    newInd.coveredNodes = coveredNodes;
                    newInd.maxEdgesCount = maxEdgesCount;
                }
            }
        }
    }
    
    private void anneal()
    {
        Random r = new Random();
        
        Individual newInd = new Individual( evolution, false );
        newInd.covering = covering.clone();
        
        double q = 4096., p;
        while ( q > .1 )
        {
            for (int i = 0; i < newInd.covering.length; i++) {
                int mutationIndex = r.nextInt(newInd.covering.length);
                //if ( r.nextDouble() < r.nextDouble() ) // the God of random numbers
                if ( r.nextBoolean() )
                    newInd.covering[mutationIndex] = -newInd.covering[mutationIndex];
            }

            newInd.repairDNA();
            if ( newInd.getFitness() > getFitness() )
            {
                p = 1.;
            } else 
            {
                p = Math.exp( - (getFitness() - newInd.getFitness()) / q );
            }
            
            if ( r.nextDouble() < p )
            {
                covering = newInd.covering.clone();
                fitness = newInd.fitness;
                coveredNodes = newInd.coveredNodes;
                maxEdgesCount = newInd.maxEdgesCount;
            } else {
                newInd.covering = covering.clone();
                newInd.fitness = fitness;
                newInd.coveredNodes = coveredNodes;
                newInd.maxEdgesCount = maxEdgesCount;
            }
            q /= 2.;
        }
        
    }
    
    private void repairCoveredNodes()
    {
        coveredNodes = 0;
        Random r = new Random();
        for ( int i = 0; i < covering.length; i ++ )
        {
            if ( isNodeSelected(i) ) coveredNodes++;
            if ( covering[i] > 0.2 || covering[i] < -0.2 )
                covering[i] /= 10.;
        }
    }
    
    private void repairDNA()
    {
        Random r = new Random();
        double con = 0.5;
        
        for ( Edge e : StateSpace.getEdges() )
        {
            if ( !isNodeSelected(e.getFromId()) 
                    && !isNodeSelected(e.getToId()) )
            {
                if ( r.nextBoolean() )
                {
                    if ( StateSpace.getNode(e.getFromId()).getEdges().size() >
                           StateSpace.getNode(e.getToId()).getEdges().size() )
                        covering[e.getFromId()] += con;
                    else if ( StateSpace.getNode(e.getFromId()).getEdges().size() >
                                StateSpace.getNode(e.getToId()).getEdges().size() )
                        covering[e.getToId()] += con;
                    else if ( r.nextBoolean() )
                        covering[e.getFromId()] += con;
                    else 
                        covering[e.getToId()] += con;
                } else 
                {
                    if (r.nextBoolean()) {
                        covering[e.getFromId()] += con;
                    } else {
                        covering[e.getToId()] += con;
                    }
                }
            }
        }
        
        for ( Node node : StateSpace.getNodes() )
        {
            if ( !isNodeSelected(node.getId())  ) continue;
            boolean canBeRemoved = true;
            for ( Edge e : node.getEdges() )
            {
                int from = e.getFromId();
                int to = e.getToId();
                if ( ( from == node.getId() && !isNodeSelected(to) ) 
                        || ( to == node.getId() && !isNodeSelected(from) ) )
                {
                    canBeRemoved = false;
                    break;
                }
            }
            if ( canBeRemoved && isNodeSelected(node.getId()) )
                covering[node.getId()] = 0.001 - covering[node.getId()];
        }
        
        repairCoveredNodes();
        computeFitness();
    }
    
    static void shuffleArray(int[] ar) {
        Random rnd = new Random();
        for (int i = ar.length - 1; i > 0; i--) {
            int index = rnd.nextInt(i + 1);
            // Simple swap
            int a = ar[index];
            ar[index] = ar[i];
            ar[i] = a;
        }
    }
    
    /**
     * Creates a new individual
     * 
     * @param evolution The evolution object
     * @param randomInit <code>true</code> if the individual should be
     * initialized randomly (we do wish to initialize if we copy the individual)
     */
    public Individual(AbstractEvolution evolution, boolean randomInit) {
        this.evolution = evolution;
        Random r = new Random();
        
        covering = new double[StateSpace.nodesCount()];
        varNodes = new boolean[StateSpace.nodesCount()];
        for ( int i = 0; i < varNodes.length; i++ )
        {
            varNodes[i] = true;
        }
        
        for ( Edge e : StateSpace.getEdges() )
        {
            if ( StateSpace.getNode( e.getFromId() ).getEdges().size() == 1 )
            {
                covering[e.getToId()] = r.nextDouble() / 2;
                covering[e.getFromId()] = - r.nextDouble() / 2;
                varNodes[e.getToId()] = false;
                varNodes[e.getFromId()] = false;
            }
            if ( StateSpace.getNode( e.getToId() ).getEdges().size() == 1 )
            {
                covering[e.getFromId()] = r.nextDouble() / 2;
                covering[e.getToId()] = - r.nextDouble() / 2;
                varNodes[e.getToId()] = false;
                varNodes[e.getFromId()] = false;
            }
        }
        
        if (randomInit) 
        {
            covering = new double[StateSpace.nodesCount()];
            
            for ( Node n : StateSpace.getNodes() )
            {
                double bit = r.nextDouble() - 0.5;
                if ( varNodes[n.getId()] ) covering[n.getId()] = bit;
            }
            
            repairDNA();
            if ( r.nextDouble() < 0.8 ) hillClimbing();
            
        } else {
            covering = new double[StateSpace.nodesCount()];
        }
    }

    @Override
    public boolean isNodeSelected(int j) {
        return covering[j] > 10e-13;
    }
    
    public double getNodeValue( int j )
    {
        return covering[j];
    }
    
    public void setNodeValue( int j, double val )
    {
        covering[j] = val;
    }
    
    /**
     * Evaluate the value of the fitness function for the individual. After
     * the fitness is computed, the <code>getFitness</code> may be called
     * repeatedly, saving computation time.
     */
    @Override
    public void computeFitness() {
        
        this.fitness = -coveredNodes;
        
        for ( Edge e : StateSpace.getEdges() )
        {
            if ( !isNodeSelected(e.getFromId()) 
                    && !isNodeSelected(e.getToId()) )
                this.fitness -= 100000.;
        }
    }

    /**
     * Only return the computed fitness value
     *
     * @return value of fitness function
     */
    @Override
    public double getFitness() {
        return this.fitness;
    }

    /**
     * Does random changes in the individual's genotype, taking mutation
     * probability into account.
     * 
     * @param mutationRate Probability of a bit being inverted, i.e. a node
     * being added to/removed from the vertex cover.
     */
    @Override
    public void mutate(double mutationRate) {
        
        Random r = new Random();
        
        if ( r.nextDouble() > mutationRate )
        {
            int numberOfMutations = r.nextInt( covering.length / 10 );
        
            for ( int i = 0; i < numberOfMutations; i++ )
            {
                int mutationIndex = r.nextInt(covering.length);
                if ( varNodes[mutationIndex] )
                    covering[mutationIndex] += r.nextGaussian() / 8;
            }
        }
        
        repairDNA();
        if ( r.nextDouble() < 0.0001 ) hillClimbing();
        
    }
    
    /**
     * Crosses the current individual over with other individual given as a
     * parameter, yielding a pair of offsprings.
     * 
     * @param other The other individual to be crossed over with
     * @return A couple of offspring individuals
     */
    @Override
    public Pair crossover(AbstractIndividual other) {

        Pair<Individual,Individual> result = new Pair();

        // @TODO implement your own crossover
        result.a = new Individual( evolution, false );
        result.b = new Individual( evolution, false );
        
        Random r = new Random();
        int numberOfPieces = r.nextInt( covering.length ) + 1;
        //int numberOfPieces = 13;
        int pieceLen = covering.length / numberOfPieces;
        boolean parentIsFirst = true;
        boolean mean = r.nextBoolean();
        
        if (!mean) {
            for (int i = 0; i < covering.length - 1; i += 2) {
                if (parentIsFirst) {
                    result.a.covering[i] = covering[i];
                    result.b.covering[i] = ((Individual) other).covering[i];
                } else {
                    result.b.covering[i] = covering[i];
                    result.a.covering[i] = ((Individual) other).covering[i];
                }

                if ((i + 1) % pieceLen == 0) {
                    parentIsFirst = !parentIsFirst;
                }
            }
        } else 
        {
            for ( int i = 0; i < covering.length; i++ )
            {
                if ( r.nextBoolean() )
                {
                    result.a.covering[i] = covering[i];
                    result.b.covering[i] = ( ((Individual) other).covering[i] + covering[i] ) / 2;
                } else 
                {
                    result.a.covering[i] = ((Individual) other).covering[i];
                    result.b.covering[i] = ( ((Individual) other).covering[i] + covering[i] ) / 2;
                }
            }
        }
        
        result.a.repairDNA();
        result.b.repairDNA();
        result.a.computeFitness();
        result.b.computeFitness();
        return result;
    }

    
    /**
     * When you are changing an individual (eg. at crossover) you probably don't
     * want to affect the old one (you don't want to destruct it). So you have
     * to implement "deep copy" of this object.
     *
     * @return identical individual
     */
    @Override
    public Individual deepCopy() {
        Individual newOne = new Individual(evolution, false);
        System.arraycopy(covering, 0, newOne.covering, 0, covering.length);
        newOne.coveredNodes = coveredNodes;
        
        computeFitness();
        newOne.fitness = this.fitness;
        return newOne;
    }

    /**
     * Return a string representation of the individual.
     *
     * @return The string representing this object.
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        
        boolean first = true;
        for ( int i = 0; i < covering.length; i++ )
        {
            if ( isNodeSelected(i) )
            {
                if ( !first ) 
                    sb.append( ", " );
                sb.append(i);
                first = false;
            }
        }

        return sb.toString();
    }
}
